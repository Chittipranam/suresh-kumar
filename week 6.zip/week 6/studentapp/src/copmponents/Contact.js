import { Component } from "react";

class Contact extends Component {
  render() {
    return (
      <h1>Welcome to the Contact Page of the Student Management Portal.</h1>
    );
  }
}
export default Contact;
