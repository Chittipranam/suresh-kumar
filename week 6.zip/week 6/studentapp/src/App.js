import './App.css';
import About from './copmponents/About';
import Contact from './copmponents/Contact';
import Home from './copmponents/Home';
function App() {
  return (
    <div className="App">
     <Home />
     <About />
     <Contact />
    </div>
  );
}

export default App;
